
import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ApiService } from '../api.service';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-dropdown',
  templateUrl: './dropdown.component.html',
  styleUrls: ['./dropdown.component.css']
})
export class DropdownComponent implements OnInit {

  new:any[]=[];
  data:any
  constructor(private apiService:ApiService,private http:HttpClient) { }
  drpdata = new FormGroup({
    location:new FormControl(''),
    territory:new FormControl(''),
    campus:new FormControl(''),
    
  })
  newData:any;
  campusdata:any;
  ngOnInit(): void {
 this.apiService.getdata().subscribe((res:any)=>{
 this.new = res.locations;
 })
}
getLocationId(data:any){
console.log(data);
this.apiService.getLocationId(data)
  .subscribe(res=>{
    console.log(res)  
  this.newData = res.zones;
  console.log(this.newData)
})
  }

  getCampus(data:{locationId :any,campusId:any}){
    console.log(this.drpdata.value.campus);
    this.apiService.getCampus(data).subscribe(res=>{
      this.campusdata = res.result;
    })
  }
}
